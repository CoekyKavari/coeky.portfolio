'use client';

import { useState } from "react";
import { motion } from "framer-motion";
import Image from "next/image";

export default function Portfolio() {
  const [darkMode, setDarkMode] = useState(false);

  const sendEmail = () => {
    const email = "kavarierwin@gmail.com";
    const subject = "Hiring Inquiry";
    const body = "Hi Coeky, I would like to discuss an opportunity with you.";
    window.open(`mailto:${email}?subject=${subject}&body=${body}`, "_blank");
  };

  const skills = [
    { name: "Java", level: 0.9 },
    { name: "SQL", level: 0.85 },
    { name: "Networking", level: 0.8 },
    { name: "Web Development", level: 0.88 },
    { name: "Systems Analysis", level: 0.82 },
    { name: "Cybersecurity Fundamentals", level: 0.75 },
    { name: "Linux", level: 0.8 },
    { name: "Database Design", level: 0.83 },
    { name: "Software Development", level: 0.9 },
  ];

  const projects = [
    {
      title: "Livestock Marketing System",
      img: "/projects/livestock.png",
      desc: "Marketplace platform for livestock trading with modern UI and listings.",
    },
    {
      title: "Attendance Management System",
      img: "/projects/attendance.png",
      desc: "Java-based student attendance tracking and reporting system.",
    },
    {
      title: "Network Infrastructure Project",
      img: "/projects/network.png",
      desc: "LAN architecture, subnetting, routing and connectivity testing.",
    },
  ];

  return (
    <main className={`${darkMode ? "dark" : ""} scroll-smooth`}>
      <div className="fixed top-6 right-6 z-50">
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="px-4 py-2 rounded-full border border-black dark:border-white hover:scale-105 transition"
        >
          {darkMode ? "Light Mode" : "Dark Mode"}
        </button>
      </div>

      <section className="relative min-h-screen flex flex-col justify-center items-center text-center px-6 overflow-hidden bg-white dark:bg-black text-black dark:text-white">
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-7xl font-bold mb-6"
        >
          Coeky Kavari
        </motion.h1>

        <p className="text-lg md:text-xl max-w-2xl mb-8 text-gray-600 dark:text-gray-300">
          Informatics student building software systems, networks, and digital tools that solve real problems.
        </p>

        <div className="flex gap-4 flex-wrap justify-center">
          <button
            onClick={sendEmail}
            className="px-6 py-3 rounded-2xl bg-black text-white dark:bg-white dark:text-black font-semibold hover:scale-105 transition"
          >
            Hire Me
          </button>

          <a
            href="/ERWIN_KAVARI_CV.pdf"
            download
            className="px-6 py-3 rounded-2xl border border-black dark:border-white hover:scale-105 transition"
          >
            Download CV
          </a>
        </div>
      </section>

      <section className="py-24 px-6 max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold mb-10 text-center">Skills Stack</h2>

        <div className="grid md:grid-cols-3 gap-6">
          {skills.map((skill) => (
            <div key={skill.name} className="p-6 rounded-2xl border">
              <h3 className="font-semibold mb-2">{skill.name}</h3>
              <div className="w-full h-3 bg-gray-300 rounded-full overflow-hidden">
                <div
                  className="h-full bg-black"
                  style={{ width: `${skill.level * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">Selected Projects</h2>

        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div key={project.title} className="rounded-2xl overflow-hidden border">
              <Image src={project.img} alt={project.title} width={400} height={208} />
              <div className="p-6">
                <h3 className="font-semibold text-lg mb-2">{project.title}</h3>
                <p className="text-sm">{project.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 px-6 text-center">
        <h2 className="text-3xl font-bold mb-6">Let’s Work Together</h2>
        <button
          onClick={sendEmail}
          className="px-8 py-4 rounded-2xl bg-black text-white font-semibold hover:scale-105 transition"
        >
          Email Me
        </button>
      </section>
    </main>
  );
}