export const metadata = {
  title: "Coeky Kavari Portfolio",
  description: "Software, networking and systems portfolio",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}